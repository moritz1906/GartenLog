# 🌱 GartenLog – Deployment via GitHub → Cloudflare Pages

## Projektstruktur

```
gartenlog/
├── .github/
│   └── workflows/
│       └── deploy.yml        ← GitHub Actions (automatisches Deployment)
├── public/
│   ├── index.html            ← die App
│   ├── _headers              ← Cloudflare Cache-Regeln
│   └── _redirects            ← SPA-Routing
├── wrangler.toml             ← Cloudflare Konfiguration
└── .gitignore
```

---

## Setup (einmalig, ~5 Minuten)

### Schritt 1 – Cloudflare API Token erstellen

1. Öffne [dash.cloudflare.com](https://dash.cloudflare.com) → **My Profile** → **API Tokens**
2. Klick **Create Token**
3. Vorlage wählen: **Edit Cloudflare Workers** (oder Custom Token)
4. Berechtigungen setzen:
   - **Account** → `Cloudflare Pages` → `Edit`
5. Token erstellen und kopieren ✓

### Schritt 2 – Account ID herausfinden

1. Öffne [dash.cloudflare.com](https://dash.cloudflare.com)
2. Wähle eine Domain (oder die Startseite)
3. Rechte Seitenleiste → **Account ID** kopieren ✓

### Schritt 3 – GitHub Secrets hinterlegen

In deinem GitHub Repository:
1. **Settings** → **Secrets and variables** → **Actions**
2. Zwei Secrets anlegen:

| Name | Wert |
|------|------|
| `CLOUDFLARE_API_TOKEN` | Token aus Schritt 1 |
| `CLOUDFLARE_ACCOUNT_ID` | ID aus Schritt 2 |

### Schritt 4 – Cloudflare Pages Projekt erstellen

1. Öffne [pages.cloudflare.com](https://pages.cloudflare.com)
2. **Create a project** → **Connect to Git**
3. GitHub-Repo auswählen
4. Build-Einstellungen:
   - **Framework preset**: `None`
   - **Build command**: *(leer lassen)*
   - **Build output directory**: `public`
5. **Save and Deploy** klicken

### Schritt 5 – Deployment testen

Pushe eine Änderung auf `main`:

```bash
git add .
git commit -m "initial deploy"
git push origin main
```

GitHub Actions startet automatisch → unter **Actions** Tab den Status sehen.

---

## Lokale Entwicklung

Einfach `public/index.html` im Browser öffnen – kein Build-Schritt nötig.
